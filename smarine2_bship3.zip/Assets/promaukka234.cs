﻿using UnityEngine;
using System.Collections;

public class promaukka234 : MonoBehaviour {

		private Transform target;
		private float speed = 10f;
		private Vector3 speedRot = Vector3.right * 50f;
		private Vector3 ballPosition;
		private Vector3 originalplace;
		private bool ballIsActive;
	private Vector2 ballInitialForce;
	float x;
	float y;
	float z;
	Vector3 pos;
	// GameObject
	public GameObject playerObject;
	public GameObject ballObject;
	public static float timem2;

	//net
	float delay = 0.5f;
	float threshold = 0.1f;

		void Start () {
		ballInitialForce = new Vector2 (10.0f,10.0f);

		// set to inactive
		ballIsActive = false;

		// ball position
		ballPosition = transform.position;
		target = GameObject.FindGameObjectWithTag("Player").transform;
		GetComponent<Rigidbody2D>().isKinematic = false;
		//original place of ball dropped in the scene...
		x = Random.Range(-25, 26);
		y = 5;
		z = Random.Range(-25, 26);
		pos = new Vector3(x, y, z);
			originalplace.y = transform.position.y;
		} 

		void Update () {
		if (GameObject.Find ("Player") != null) {
		} else {
			//Destroy (this.gameObject, 2);
		}
		//transform.position = pos;
			transform.Rotate (speedRot * Time.deltaTime);
	
		if (transform.position.y < -3) {
			//Destroy (this.gameObject, 0.1f);
		}
		if (GameObject.Find ("Player") != null) {
			transform.position = Vector3.MoveTowards (transform.position, target.position, Random.Range (speed, 20f) * Time.deltaTime);
		}

	}
	void OnCollisionEnter2D(Collision2D collision){

		if (collision.gameObject.tag == "onthetop") {
			//DestroyObject (ballObject);
			//Debug.Log("jj");
			x = Random.Range(-25, 26);
			y = 5;
			z = Random.Range(-25, 26);
			pos = new Vector3(x, y, z);
			//Start ();
			//originalplace.y = transform.position.y;
			Vector3 temp = transform.position;
			//if (GameObject.Find ("Player") != null) {
			//	if(this.gameObject != null) 
			//string name = playerObject.ToString();
			//if(GameObject.Find(name) != null)
				temp.x = playerObject.transform.position.x;

				temp.y = originalplace.y;
				transform.position = temp;
		}
	}

	}
