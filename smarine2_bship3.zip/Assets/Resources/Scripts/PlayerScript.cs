﻿using UnityEngine;
using System.Collections;

public class PlayerScript : MonoBehaviour {

	public float playerVelocity;
	private Vector3 playerPosition;
	public float boundary;
	public Object particleSystems;
	private int playerLives;

	public GameObject prefabEffect;
	public Transform fpcontoler;
	public GameObject hand;
	public ParticleSystem ps2;
	public float turnSpeed = 50f;
	// Use this for initialization
	void Start () {
		// get the initial position of the game object
		playerPosition = gameObject.transform.position;

		playerLives = 3;


		//onGUI ();
	}
	void Awake() {
		particleSystems = Resources.Load ("Explosions/Explosion02", typeof(GameObject)); 
	}

	
	
	// Update is called once per frame
	void Update () {
		
		transform.RotateAround(Vector3.zero, Vector3.up, 20 * Time.deltaTime);
		playerPosition.x += Input.GetAxis("Horizontal") * playerVelocity;

		if(Input.GetKey(KeyCode.M))
			transform.Rotate(Vector3.up, turnSpeed * Time.deltaTime);
		
		// leave the game
		if (Input.GetKeyDown(KeyCode.Escape)){
			Application.Quit();
		}
		if (Input.GetKeyDown(KeyCode.F)){
			// horizontal movement
			//transform.RotateAround(Vector3.zero, Vector3.up, 20 * Time.deltaTime); //20 * Time.deltaTime
			transform.RotateAround(transform.position, transform.up, 180f);
		}

		// update the game object transform
		transform.position = playerPosition;

		// boundaries
		if (playerPosition.x < -boundary) {
						transform.position = new Vector3 (-boundary, playerPosition.y, playerPosition.z);		
				} 
		if (playerPosition.x > boundary) {
			transform.position = new Vector3(boundary, playerPosition.y, playerPosition.z);		
		}



	}
	void OnCollisionEnter2D(Collision2D collision){

		if (collision.gameObject.tag == "ballm") {
			

			//
			//Debug.Log ("lisääsli0923493242");
			//GameObject go4;
			//prefabEffect.transform.SetParent (fpcontoler);
			//string m0;
			//m0 = gameObject.transform.GetChild (0).name;
			//hand = GameObject.Find("Player/Explosionx/Flame");
			//hand.SetActive (true);
			ps2.Play ();

			//GameObject go3 = Instantiate(hand) as GameObject;
			//go3.transform.parent = gameObject.transform;
			//fpcontoler = go3.transform;
			//go3.transform.SetParent (fpcontoler);
			//go3.transform.parent = transform;
			//prefabEffect.transform.parent = transform;
			//go3.transform.parent = fpcontoler;
			//GameObject ps = particleSystem.name;
			//GameObject go = Instantiate (particleSystems, Vector3.zero, Quaternion.identity) as GameObject;
			//Destroy (go, 10);
			//GameObject go2 = Instantiate (particleSystems, Vector3.zero, Quaternion.identity) as GameObject;
			//Destroy (go2, 10);
			Destroy(GameObject.Find("Ball"), 1);
			Destroy(GameObject.Find("Ball (1)"), 1);
			Destroy(this.gameObject, 1);
		}
	}

	void OnGUI(){
		
		GUI.Label (new Rect (20f, 20f, 200.0f, 200.0f),  "  Score: " + PlayerPrefs.GetInt ("Score"));

	}

	void TakeLife(){
		playerLives--;
	}
}
