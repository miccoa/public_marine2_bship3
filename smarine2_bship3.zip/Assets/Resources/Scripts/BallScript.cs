﻿using UnityEngine;
using System.Collections;

public class BallScript : MonoBehaviour {

		private bool ballIsActive;
		private Vector3 ballPosition;
		private Vector3 originalplace;
		private Vector2 ballInitialForce;
		
		// GameObject
		public GameObject playerObject;
		public GameObject ballObject;
		

	// Use this for initialization
	public static float timem2;

	void Start () {
			// create the force
			//ballInitialForce = new Vector2 (100.0f,800.0f);
			
			// set to inactive
			ballIsActive = false;
			
			// ball position
			ballPosition = transform.position;

			//original place of ball
			originalplace.y = transform.position.y;
		}
		void Awake() {
				//Start ();
		}
		//public Texture btnTexture;
		void OnGUI() {
				//if (!btnTexture) {
				//		Debug.LogError("Please assign a texture on the inspector");
				//		return;
				//}
		if (GUI.Button (new Rect (30, 0, 100, 20), "New game")) {
						Application.LoadLevel ("Level1"); //Awake ();//Debug.Log("Clicked the button with an image");
		}
		if (GUI.Button (new Rect (30, 50, 100, 20), "Random")) {
			Application.LoadLevel ("Level10"); //Awake ();//Debug.Log("Clicked the button with an image");
		}
//		if (GUI.Button (new Rect (0, 50, 100, 20), "Next Level")) {
			

//			if (Application.loadedLevelName.Equals ("Level1")) {
//				Application.LoadLevel ("level.2");
//			}
//			if (Application.loadedLevelName.Equals ("level.2")) {
//				Application.LoadLevel ("lev4"); //Awake ();//Debug.Log("Clicked the button with an image");
//			}
//			if (Application.loadedLevelName.Equals ("lev4")) {
//				Application.LoadLevel ("5"); //Awake ();//Debug.Log("Clicked the button with an image");
//			}
//			if (Application.loadedLevelName.Equals ("5")) {
//				Application.LoadLevel ("Level1"); //Awake ();//Debug.Log("Clicked the button with an image");
//			}
//		}
//		if ( GUI.Button(new Rect(150, 122, 100, 50),"go to nice level", GUI.skin.button) ) {
//			Application.LoadLevel ("levu"); //Awake ();//Debug.Log("Clicked the button with an image");
//		}
		GUI.skin.button.wordWrap = true;
		if ( GUI.Button(new Rect(20, 200, 50, 20),"Exit", GUI.skin.button) ) {
			Application.Quit (); //Awake ();//Debug.Log("Clicked the button with an image");
		}
				//if (GUI.Button(new Rect(10, 70, 50, 30), "Click"))
				//		Debug.Log("Clicked the button with text");
			
//			GUI.Label(new Rect(20,80,250,100), "");

			int minutes = Mathf.FloorToInt(timem2 / 60F);
			int seconds = Mathf.FloorToInt(timem2 - minutes * 60);
		string niceTime = string.Format("{0:00}:{1:0}", minutes, seconds);

			//GUI.Label(new Rect(80,200,250,100), niceTime);

		GUIStyle myStyle = new GUIStyle (GUI.skin.GetStyle("label"));
		myStyle.fontSize = 32;
		//GUI.Label (new Rect (100, 300, 200, 210), "Level",myStyle);
		//3rd p, screen.width jaet 2, height 4 p, jaet 2
		}
		
		// Update is called once per frame
		void Update () {
		if (GameObject.Find ("Player") != null) {
		} else {
			//Destroy (this.gameObject, 2);
		}
		timem2 += Time.deltaTime;

			// check for user input
			if (Input.GetButtonDown ("Jump") == true) {
				// check if is the first play
				if (!ballIsActive){
					// reset the force
					GetComponent<Rigidbody2D>().isKinematic = false;
					//GetComponent<Rigidbody2D>().AddForce();
					// add a force
					//GetComponent<Rigidbody2D>().AddForce(ballInitialForce);
				//GetComponent<Rigidbody2D>().velocity =  new Vector2(2*5f * Time.deltaTime, GetComponent<Rigidbody2D>().velocity.y);


				GetComponent<Rigidbody2D> ().velocity = new Vector2 (0, -20);

				//Debug.Log ("Talla jutulla" + ballInitialForce);
					//transform.position = transform.position + 30 * transform.forward;
					// set ball active
					
				ballIsActive = !ballIsActive;
//				GetComponent<Rigidbody2D>().isKinematic = false;
//				ballPosition.y = playerObject.transform.position.y - 1f;
//				ballPosition.x = playerObject.transform.position.x;
//				transform.position = ballPosition;
				}
			}
				if (Input.GetKeyDown (KeyCode.P)) {
						//ballPosition = transform.position;

			//ballInitialForce = new Vector2 (100.0f,800.0f);
			ballIsActive = !ballIsActive;
			GetComponent<Rigidbody2D>().isKinematic = false;
			ballPosition.y = playerObject.transform.position.y - 1f;
			ballPosition.x = playerObject.transform.position.x;
			transform.position = ballPosition;


//						ballIsActive = !ballIsActive;
//						ballPosition.x = playerObject.transform.position.x;
//						ballPosition.y = originalplace.y;//playerObject.transform.position.y;
//						transform.position = ballPosition;
					

						GetComponent<Rigidbody2D>().isKinematic = true;
				}
			
			if (!ballIsActive && playerObject != null){
				
				// get and use the player position
				ballPosition.x = playerObject.transform.position.x;
				
				// apply player X position to the ball
				transform.position = ballPosition;
			}
			
			
			// Check if ball falls
			if (ballIsActive && transform.position.y < -15.2f) {
				ballIsActive = !ballIsActive;
			//string name = playerObject.ToString();
			//if(GameObject.Find(name) != null)
				ballPosition.x = playerObject.transform.position.x;
				ballPosition.y = originalplace.y; //-4.2f too
				transform.position = ballPosition;
				
				GetComponent<Rigidbody2D>().isKinematic = true;

				playerObject.SendMessage("TakeLife");
			}
			
		}
	void OnCollisionEnter2D(Collision2D collision){

		if (collision.gameObject.tag == "bottomplace") {
			//DestroyObject (ballObject);
			//Debug.Log("je");
			ballIsActive = !ballIsActive;
			ballPosition.y = originalplace.y;
			//ballPosition = transform.position;
			GetComponent<Rigidbody2D>().isKinematic = true;
		}
	}

	}