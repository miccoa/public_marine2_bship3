﻿using UnityEngine;
using System.Collections;

public class ballscript2 : MonoBehaviour {

		private bool ballIsActive;
		private Vector3 ballPosition;
		private Vector3 originalplace;
		private Vector2 ballInitialForce;

		// GameObject
		public GameObject playerObject;
		public GameObject ballObject;
	public static float timem2;
		// Use this for initialization
		

		void Start () {
			// create the force
		ballInitialForce = new Vector2(100.0f,1000.0f);

			// set to inactive
			ballIsActive = false;

			// ball position
			ballPosition = transform.position;

			//original place of ball
			originalplace.y = transform.position.y;
		// Debug.Log ("invokeeivält");
		}
		void Awake() {
			Start ();
		}
		//public Texture btnTexture;

		void Update () {



			// check for user input
			if (Input.GetKeyDown (KeyCode.E)) {
				// check if is the first play
				if (!ballIsActive){
					// reset the force
					GetComponent<Rigidbody2D>().isKinematic = false;

					// add a force
					GetComponent<Rigidbody2D>().AddForce(ballInitialForce);

					// set ball active
					ballIsActive = !ballIsActive;
				}
			}
			if (Input.GetKeyDown (KeyCode.R)) {
				//ballPosition = transform.position;
				ballIsActive = !ballIsActive;
				//ballPosition.x = playerObject.transform.position.x;
				ballPosition.y = originalplace.y;//playerObject.transform.position.y;

				//ballPosition.y = ballPosition.y - 20;
				//ballPosition.y = -4.2f;
				//transform.position = ballPosition;

				GetComponent<Rigidbody2D>().isKinematic = true;
			}

			if (!ballIsActive && playerObject != null){

				// get and use the player position
				ballPosition.x = playerObject.transform.position.x;

				// apply player X position to the ball
				transform.position = ballPosition;
			}


			// Check if ball falls
			if (ballIsActive && transform.position.y < -6) {
				ballIsActive = !ballIsActive;
				ballPosition.x = playerObject.transform.position.x;
				ballPosition.y = -4.2f;
				transform.position = ballPosition;

				GetComponent<Rigidbody2D>().isKinematic = true;

				playerObject.SendMessage("TakeLife");
			}

		}
		void OnCollisionEnter2D(Collision2D collision){

			if (collision.gameObject.tag == "onthetop") {
				//DestroyObject (ballObject);
				//Debug.Log("je");
				ballIsActive = !ballIsActive;
				ballPosition.y = originalplace.y;
				//ballPosition = transform.position;
				GetComponent<Rigidbody2D>().isKinematic = true;
			}
		}

	}
