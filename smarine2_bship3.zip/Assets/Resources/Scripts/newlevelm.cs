﻿using UnityEngine;
using System.Collections;
using System;

public class newlevelm : MonoBehaviour {
	public BlockScript ref2;
	//public int playerPoints;
	public static float timem2;
	public GameObject prefab;
	public GameObject prefab2;
	private string stringtoedit = "3";
	public int inttoedit  = 0;
	public int numberOfObjects = 0;
	public float radius = 10f;
	public float somefloat;
	public int missiles;
	public int score;
	public GameObject[] gos;
		private int playerLives;
	private int playerPoints;


	IEnumerator MyLoadLevel(int taso)
	{
		yield return new WaitForSeconds (2);
		Application.LoadLevel (taso);
	}

	// Use this for initialization
	void Start () {

		if (Application.loadedLevelName.Equals ("Level10")) {
			//aloitetaan 20 vastuksella

			score = 0;
			stringtoedit = PlayerPrefs.GetString ("Text Area");
			PlayerPrefs.SetString("Text Area", stringtoedit);
			numberOfObjects = Convert.ToInt32(PlayerPrefs.GetString("Text Area"));// PlayerPrefs.GetInt("Player Score");
			for (int i = 0; i < numberOfObjects; i++) {
				float angle = i * Mathf.PI * 2 / numberOfObjects;
				Vector3 pos = new Vector3 (Mathf.Cos (angle), 0, Mathf.Sin (angle)) * radius;
				Instantiate (prefab, pos, Quaternion.identity);
				Instantiate (prefab2, pos, Quaternion.identity);
			}
		

		}

		if (Application.loadedLevelName.Equals ("Level1")) {
			//aloitetaan 20 vastuksella
			PlayerPrefs.SetString("Text Area", "5");
			score = 0;
		stringtoedit = PlayerPrefs.GetString ("Text Area");
			numberOfObjects = Convert.ToInt32(PlayerPrefs.GetString("Text Area"));// PlayerPrefs.GetInt("Player Score");
			for (int i = 0; i < numberOfObjects; i++) {
				float angle = i * Mathf.PI * 2 / numberOfObjects;
				Vector3 pos = new Vector3 (Mathf.Cos (angle), 0, Mathf.Sin (angle)) * radius;
				Instantiate (prefab, pos, Quaternion.identity);
				Instantiate (prefab2, pos, Quaternion.identity);
			}
		}
		if (Application.loadedLevelName.Equals ("Level2")) {
			//aloitetaan 20 vastuksella
			PlayerPrefs.SetString("Text Area", "20");

			score = 0;
			stringtoedit = PlayerPrefs.GetString ("Text Area");
			numberOfObjects = Convert.ToInt32(PlayerPrefs.GetString("Text Area"));// PlayerPrefs.GetInt("Player Score");
			for (int i = 0; i < numberOfObjects; i++) {
				float angle = i * Mathf.PI * 2 / numberOfObjects;
				Vector3 pos = new Vector3 (Mathf.Cos (angle), 0, Mathf.Sin (angle)) * radius;
				Instantiate (prefab, pos, Quaternion.identity);
				Instantiate (prefab2, pos, Quaternion.identity);
			}
		}

		if (Application.loadedLevelName.Equals ("Level3")) {
			//aloitetaan 20 vastuksella
			PlayerPrefs.SetString("Text Area", "30");

			score = 0;
			stringtoedit = PlayerPrefs.GetString ("Text Area");
			numberOfObjects = Convert.ToInt32(PlayerPrefs.GetString("Text Area"));// PlayerPrefs.GetInt("Player Score");
			for (int i = 0; i < numberOfObjects; i++) {
				float angle = i * Mathf.PI * 2 / numberOfObjects;
				Vector3 pos = new Vector3 (Mathf.Cos (angle), 0, Mathf.Sin (angle)) * radius;
				Instantiate (prefab, pos, Quaternion.identity);
				Instantiate (prefab2, pos, Quaternion.identity);
			}
		}

		if (Application.loadedLevelName.Equals ("Level4")) {
			//aloitetaan 20 vastuksella
			PlayerPrefs.SetString("Text Area", "40");

			score = 0;
			stringtoedit = PlayerPrefs.GetString ("Text Area");
			numberOfObjects = Convert.ToInt32(PlayerPrefs.GetString("Text Area"));// PlayerPrefs.GetInt("Player Score");
			for (int i = 0; i < numberOfObjects; i++) {
				float angle = i * Mathf.PI * 2 / numberOfObjects;
				Vector3 pos = new Vector3 (Mathf.Cos (angle), 0, Mathf.Sin (angle)) * radius;
				Instantiate (prefab, pos, Quaternion.identity);
				Instantiate (prefab2, pos, Quaternion.identity);
			}
		}

		if (Application.loadedLevelName.Equals ("Level5")) {
			//aloitetaan 20 vastuksella
			PlayerPrefs.SetString("Text Area", "50");

			score = 0;
			stringtoedit = PlayerPrefs.GetString ("Text Area");
			numberOfObjects = Convert.ToInt32(PlayerPrefs.GetString("Text Area"));// PlayerPrefs.GetInt("Player Score");
			for (int i = 0; i < numberOfObjects; i++) {
				float angle = i * Mathf.PI * 2 / numberOfObjects;
				Vector3 pos = new Vector3 (Mathf.Cos (angle), 0, Mathf.Sin (angle)) * radius;
				Instantiate (prefab, pos, Quaternion.identity);
				Instantiate (prefab2, pos, Quaternion.identity);
			}
		}

	}

		void addPoints(int points){
		playerPoints += points;
	}
	
	// Update is called once per frame
	void Update () {
		if (Application.loadedLevelName.Equals ("Level10")) {

			gos = GameObject.FindGameObjectsWithTag("sub");//open new level after 2 subs left...,.
			if(gos.Length == 2)
			{
				//Debug.Log ("2 opjekts");
				StartCoroutine (MyLoadLevel (6));
				// Do Something
			}
		}



		if (Application.loadedLevelName.Equals ("Level1")) {
			if (PlayerPrefs.GetInt ("Score") >= 50) {
				StartCoroutine (MyLoadLevel(2));
			}
		}

		if (Application.loadedLevelName.Equals ("Level2")) {
			if (PlayerPrefs.GetInt ("Score") >= 200) {
				StartCoroutine (MyLoadLevel(3));
			}
		}

		if (Application.loadedLevelName.Equals ("Level3")) {
			if (PlayerPrefs.GetInt ("Score") >= 300) {
				StartCoroutine (MyLoadLevel(4));
			}
		}

		if (Application.loadedLevelName.Equals ("Level4")) {
			if (PlayerPrefs.GetInt ("Score") >= 400) {
				StartCoroutine (MyLoadLevel(5));
			}
		}

		if (Application.loadedLevelName.Equals ("Level5")) {
			if (PlayerPrefs.GetInt ("Score") >= 480) {
				StartCoroutine (MyLoadLevel(6));
			}
		}

		timem2 += Time.deltaTime;
		if (Input.GetKeyDown (KeyCode.L)) {
			Application.LoadLevel (0);
		}
		if (Input.GetKeyDown (KeyCode.Z)) {
			Application.LoadLevel (4);
			// CTRL + Z
		}
		bool left2 = false;
		bool right2 = false;

		var leftDown = Input.GetButton ("Horizontal");
		var rightDown = Input.GetButton ("Horizontal");
		if (leftDown) {
			left2 = true;
			// Rotate left
			//Application.LoadLevel (2);
		} else if (rightDown) {
			// Move forward
			right2 = true;
			Debug.Log (right2); 
		} 
		else if (right2 == true) {
			Application.LoadLevel (2);
			left2 = false; right2 = false;
		}
	
	}

	void OnGUI() {
		//if (!btnTexture) {
		//		Debug.LogError("Please assign a texture on the inspector");
		//		return;
		//}




			
			stringtoedit = GUI.TextField (new Rect (20, 80, 100, 20), stringtoedit, 200);

			if (GUI.Button(new Rect(20, 120, 60, 20), "Save"))
				PlayerPrefs.SetString("Text Area", stringtoedit);
			if (GUI.Button(new Rect(20, 140, 60, 20), "Load"))
				stringtoedit = PlayerPrefs.GetString("Text Area");
		
		//inttoedit = GUI.TextField(new Rect(10, 10, 200, 20), inttoedit, 10);
		//stringtoedit = GUI.TextField(new Rect(10, 10, 20, 20), stringtoedit, 25);
		//print (stringtoedit);
		//inttoedit = int.Parse (stringtoedit);

		//GUILayout.BeginHorizontal();
		//GUILayout.Label("size of Hall " + somefloat);
		//somefloat = GUILayout.HorizontalScrollbar((int)somefloat,0.01f, 0f, 300.1f,GUILayout.Width(50));
		//GUILayout.EndHorizontal();

		//PlayerPrefs.SetInt("Player Score", inttoedit);
		//print(PlayerPrefs.GetInt("Player Score"));
		Event e = Event.current;
		if (e.type == EventType.KeyDown && e.control && e.keyCode == KeyCode.V)
		{
			Application.LoadLevel (5);
			// CTRL + Z
		}

		if (e.type == EventType.KeyDown && e.control && e.keyCode == KeyCode.C)
		{
			Application.LoadLevel (6);
			// CTRL + Z
		}

		if (e.type == EventType.KeyDown && e.control && e.keyCode == KeyCode.X)
		{
			Application.LoadLevel (7);
			// CTRL + Z
		}

		if (e.type == EventType.KeyDown && e.control && e.keyCode == KeyCode.W)
		{
			Application.LoadLevel (8);
			// CTRL + Z
		}

		if (e.type == EventType.KeyDown && e.control && e.keyCode == KeyCode.E)
		{
			Application.LoadLevel (9);
			// CTRL + Z
		}

		if (e.type == EventType.KeyDown && e.control && e.keyCode == KeyCode.R)
		{
			Application.LoadLevel (10);
			// CTRL + Z
		}

		if (e.type == EventType.KeyDown && e.control && e.keyCode == KeyCode.T)
		{
			Application.LoadLevel (11);
			// CTRL + Z
		}
		//GUI.Label (new Rect(425.0f,30.0f,200.0f,200.0f), "  Score: " + score);
//		if ( GUI.Button(new Rect(130, 83, 100, 50),"Add", GUI.skin.button) ) {
//			playerPoints = playerPoints + 50;
//
//
//		}
//		if (Application.loadedLevelName.Equals ("levu")) {
//			if (GUI.Button (new Rect (50, 40, 100, 50), "Next Level")) {
//
//				if (Application.loadedLevelName.Equals ("levu")) {
//					Application.LoadLevel ("Level1"); //Awake ();//Debug.Log("Clicked the button with an image");
//				}
//			}
//		}
//		if (Application.loadedLevelName.Equals ("Level2")) {
//			GUI.Label(new Rect(500,0,250,100), "not promoter of head to head combat tactics, sorry for that");
//		}
//
//		if (GUI.Button (new Rect (30, 0, 100, 50), "New game")) {
//			Application.LoadLevel ("Level1"); //Awake ();//Debug.Log("Clicked the button with an image");
//			timem2 = 0f;
//		}
//		if (GUI.Button (new Rect (50, 40, 100, 50), "Next Level")) {
//
//
//			if (Application.loadedLevelName.Equals ("Level1")) {
//				Application.LoadLevel ("Level2");
//			}
//			if (Application.loadedLevelName.Equals ("Level2")) {
//				Application.LoadLevel ("Level1"); //Awake ();//Debug.Log("Clicked the button with an image");
//			}
//			if (Application.loadedLevelName.Equals ("lev4")) {
//				Application.LoadLevel ("5"); //Awake ();//Debug.Log("Clicked the button with an image");
//			}
//			if (Application.loadedLevelName.Equals ("5")) {
//				Application.LoadLevel ("Level1"); //Awake ();//Debug.Log("Clicked the button with an image");
//			}
//		}
//		if ( GUI.Button(new Rect(150, 122, 100, 50),"go to nice level", GUI.skin.button) ) {
//			Application.LoadLevel ("levu"); //Awake ();//Debug.Log("Clicked the button with an image");
//		}
//		GUI.skin.button.wordWrap = true;
//		if ( GUI.Button(new Rect(202, 292, 250, 50),"x is nice too but this should work sometimes too", GUI.skin.button) ) {
//			Application.Quit (); //Awake ();//Debug.Log("Clicked the button with an image");
//		}
//		//if (GUI.Button(new Rect(10, 70, 50, 30), "Click"))
//		//		Debug.Log("Clicked the button with text");
//
//		GUI.Label(new Rect(20,80,250,100), "Meit pai Aloittelija00m02m");

		int minutes = Mathf.FloorToInt(timem2 / 60F);
		int seconds = Mathf.FloorToInt(timem2 - minutes * 60);
		string niceTime = string.Format("{0000:0}:{001:00}", minutes, seconds);

		GUI.Label(new Rect(80,200,250,100), niceTime);

		GUIStyle myStyle = new GUIStyle (GUI.skin.GetStyle("label"));
		myStyle.fontSize = 18;

		if (Application.loadedLevelName.Equals ("Level1")) {
		GUI.Label (new Rect (100, 300, 200, 210), "Level1",myStyle);
		}
		if (Application.loadedLevelName.Equals ("Level2")) {
			GUI.Label (new Rect (100, 300, 200, 210), "Level2",myStyle);
		}
		if (Application.loadedLevelName.Equals ("Level3")) {
			GUI.Label (new Rect (100, 300, 200, 210), "Level3",myStyle);
		}
		if (Application.loadedLevelName.Equals ("Level4")) {
			GUI.Label (new Rect (100, 300, 200, 210), "Level4",myStyle);
		}
		if (Application.loadedLevelName.Equals ("Level5")) {
			GUI.Label (new Rect (100, 300, 200, 210), "Level5",myStyle);
		}
		if (Application.loadedLevelName.Equals ("Level10")) {
			GUI.Label (new Rect (100, 300, 200, 210), "Random",myStyle);
		}
		
		GUI.Label (new Rect (100, 350, 200, 210), "Controls: Space, h, p",myStyle);
		//3rd p, screen.width jaet 2, height 4 p, jaet 2
	}
}
