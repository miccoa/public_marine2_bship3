﻿
	using UnityEngine;
	using System.Collections;
	using UnityEngine.UI;

	public class LevelManager : MonoBehaviour {
		public int coins;

		//public IEnumerator RespawnCoroutine(){
			/*gamePlayer.gameObject.SetActive (false);
			yield return new WaitForSeconds (respawnDelay);
			gamePlayer.transform.position = gamePlayer.respawnPoint;
			gamePlayer.gameObject.SetActive (true);*/
		//}
		public void AddCoins(int numberOfCoins){
			coins += numberOfCoins;
		}
	}
